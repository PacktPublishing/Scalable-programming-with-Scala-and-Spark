import org.apache.spark.{SparkContext, SparkConf}


object Accumulator {


  def main (args: Array[String]){

    val conf= new SparkConf().setMaster("yarn-client").setAppName("My App")
    val sc= new SparkContext(conf)

    val logsPath="hdfs:///user/swethakolalapudi/log/hbase.log"
    val logs=sc.textFile(logsPath)
    val errCount=sc.accumulator(0)
    def processLog(line: String): String = {

      if (line.contains("ERROR")){
        errCount += 1
      }
      line
    }
    logs.map(processLog).saveAsTextFile("hdfs:///user/swethakolalapudi/log/processedLogs2.log")
    println("There were " + errCount.value.toString +" ERROR lines")

  }

}
