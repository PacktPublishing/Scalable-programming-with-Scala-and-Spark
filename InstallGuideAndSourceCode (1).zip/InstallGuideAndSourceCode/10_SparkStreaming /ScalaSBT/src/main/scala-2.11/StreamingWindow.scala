import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object StreamingWindow {

   def main (args: Array[String]){
     val conf= new SparkConf().setMaster("yarn-client").setAppName("My App")
     val sc= new SparkContext(conf)


     val ssc = new StreamingContext(sc, Seconds(1))
     ssc.checkpoint("hdfs:///user/swethakolalapudi/streaming")
     val lines = ssc.socketTextStream(args(0), args(1).toInt)
     val counts = lines.filter(_.contains("Error")).
       flatMap(_.split(" ")).map( word => (word, 1)).
       reduceByKeyAndWindow(
       {(x,y) => x+y},
     {(x,y) => x-y},
     Seconds(30),Seconds(10))

     counts.print()

     ssc.start()
     ssc.awaitTermination()
   }




 }
