/**
 * Created by swethakolalapudi on 7/29/16.
 */
object FunctionMethod {

  def main (args: Array[String]){

    val maxfnobject = (x: Int ,y: Int) => max(x,y)

  }

  def max(x:Int, y:Int): Int= {
    if (x>y)
    x
    else
    y
  }

}
