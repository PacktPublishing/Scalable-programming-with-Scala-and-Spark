
public class Circle extends  Shape{

     public Double radius;
     private static Double PI = 3.14;

     Circle(Double radius){
          this.radius=radius;
     }

     public Double getArea(){
          return  PI*radius*radius;
      };

}
