class Person(xc: Double,yc: Double,r: Double) {

  val x = xc
  val y = yc
  val range = r

}
