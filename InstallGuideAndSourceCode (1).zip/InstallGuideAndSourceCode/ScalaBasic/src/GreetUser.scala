/**
 * Created by swethakolalapudi on 7/29/16.
 */
object GreetUser {

  def main (args: Array[String]){

    val greetEnglish = greeting("English")
    greetEnglish("Swetha")

    val greetSpanish = greeting("Spanish")
    greetSpanish("Janani")

  }


  def greeting(lang: String)= {

    lang match {

      case "English" => (x: String) => println("Hello "+x)

      case "Hindi" => (x: String) => println("Namaste "+x)

      case "French" => (x: String) => println("Bonjour "+x)

      case "Spanish" => (x: String) => println("Hola "+x)

    }
  }

}
