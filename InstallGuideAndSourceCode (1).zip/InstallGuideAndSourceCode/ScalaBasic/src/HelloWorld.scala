/**
 * Created by swethakolalapudi on 7/29/16.
 */
object HelloWorld {

  def main (args: Array[String]){

    println("Hello World!")

  }

}
