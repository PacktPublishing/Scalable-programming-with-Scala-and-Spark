/**
 * Created by swethakolalapudi on 7/15/16.
 */
public class printShape {

    public static void main(String[] args){


        Shape shape = new Rectangle(2.0,3.0);

        if (shape instanceof Rectangle){
            Rectangle rect = (Rectangle) shape;
            System.out.println(rect.width.toString()+ " " +rect.height.toString());
        }
        else if (shape instanceof Circle){
            Circle circ = (Circle) shape;
            System.out.println(circ.radius.toString());
        }
        else if (shape instanceof Triangle){
            Triangle tri = (Triangle) shape;
            System.out.println(tri.base.toString()+ " " +tri.height.toString());
        }

    }
}
