/**
 * Created by swethakolalapudi on 7/29/16.
 */
object TestRational {


  def main (args: Array[String]){

    val q = new Rational(2,3);

    println(q.numer);

    println(Rational.inf);

    Rational.divideByZero(5);




  }



}
