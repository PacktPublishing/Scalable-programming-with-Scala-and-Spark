
public class Rectangle extends  Shape{

     public Double width;
     public Double height;

     Rectangle(Double width,Double height){
          this.width=width;
          this.height = height;
     }

     public Double getArea(){
          return width*height;
     };

}