
class Item(xc: Double,yc: Double) {
  val x = xc
  val y = yc


}
