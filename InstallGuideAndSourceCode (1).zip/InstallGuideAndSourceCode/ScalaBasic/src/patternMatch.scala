/**
 * Created by swethakolalapudi on 7/15/16.
 */
object patternMatch {

  def main(args: Array[String]) {

    abstract class Shape;
    case class Rectangle(width: Double,height: Double) extends Shape;
    case class Circle(radius: Double) extends Shape;
    case class Triangle(base: Double, height: Double) extends Shape;

    val compareShapes = (shape1: Shape,shape2: Shape) =>
      (shape1,shape2) match {

        case (Rectangle(w1,h1),Rectangle(w2,h2)) => if(w1==w2 && h1==h2) print ("Two identical rectangles") else ("Two dissimilar rectangles")
        case (Triangle(b1,_),Triangle(b2,_)) => if(b1==b2) print ("Two triangles with the same base") else print ("Two dissimilar triangles")
        case (Circle(_),Rectangle(_,_)) => print ("A Circle and a Rectangle ")
        case (Rectangle(_,_),Circle(_)) => print ("A Rectangle and a Circle ")
        case _ => print("Other pattern")
      }

    val printAttributes = (shape: Shape) =>
      shape match {
        case Rectangle(width,height) => print(width.toString+" "+height.toString)
        case Triangle(base,height) => print(base.toString+" "+height.toString)
        case Circle(radius) => print(radius.toString)
      }


    compareShapes(new Rectangle(2.1,3.1),new Rectangle(2.1,3.1))
  }

}
