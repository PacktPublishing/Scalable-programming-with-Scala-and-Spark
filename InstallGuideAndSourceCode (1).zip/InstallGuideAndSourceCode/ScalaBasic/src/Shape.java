
import java.lang.Double;public abstract class Shape {

     abstract Double getArea();

}
